# Viktor's Blog

Hi, I’m Viktor. I’m 13 and I build code, despite my age. I work on:

- Embedded hardware (Raspberry Pi Pico W)
- Packet analyzers (Scapy + curses)
- Flask and Django web apps
- Custom protocols and compilers
- Decentralized systems


Im self-taught, and started coding at the age of 9.

Follow along if you're into Python,Raspberry Pi, JS,or decentralized social media.



