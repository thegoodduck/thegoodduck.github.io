---
title: "Building NetSour: An epic story"
date: 2025-05-09
---
### Building NetSour

I started building NetSour around six months ago, just because my WI-FI was overpassing our bills. I ended up learning so much more. I learned for the first ``scapy`` and ``curses`` learned how hard it was to build a working TUI, got my first experience of complicated bugs(i had my dose with Winternet(a social media that i developped a year ago)) and ended up having my first 100 stars on Github. It was a blast. It was.
